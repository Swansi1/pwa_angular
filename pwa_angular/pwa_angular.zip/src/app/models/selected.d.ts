export interface Selected {
    doom: HTMLElement,
    id: string
}