export interface Score {
    id: string;
    name: string;
    click: string;
    date: string;
    idbAdd: number;
  }