export interface Palya {
    x: Number,
    y: Number
}