export enum ClassColors {
    default = "col-sm p-5 m-1 text-center rounded bg-primary",
    selected = "col-sm p-5 m-1 text-center rounded bg-warning",
    notMatch = "col-sm p-5 m-1 text-center rounded bg-danger",
    match = "col-sm p-5 m-1 text-center rounded bg-success"
  }